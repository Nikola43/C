#include <stdio.h>
#include "arduino_serial_port.h"

int active_serial_port;

int main(int argc, char *argv[])
{

    if(active_serial_port = serial_port_open(argv[1], argv[2] == -1)
            perror(SERIAL_PORT_OPEN_ERROR);
    else
            printf("%s\n", SERIAL_PORT_OPEN_OK);

    serial_port_write(active_serial_port, argv[3]);
    serial_port_close(active_serial_port);

    return 0;
}
