//Include libraries
#include "arduino_serial_port.h"
#include <stdio.h>                // Standard input/output definitions
#include <string.h>               // String function definitions
#include <unistd.h>               // UNIX standard function definitions
#include <fcntl.h>                // File control definitions
#include <errno.h>                // Error number definitions
#include <termios.h>              // POSIX terminal control definitions
#include <sys/ioctl.h>

int serial_port_open(const char *serial_port_name, int baudrate)
{
    struct termios toptions;
    int fd;

    //fd = open(serialport, O_RDWR | O_NOCTTY | O_NDELAY);
    fd = open(serial_port_name, O_RDWR | O_NONBLOCK );

    if (fd == -1)
    {
        return(-1);
    }

    //int iflags = TIOCM_DTR;
    //ioctl(fd, TIOCMBIS, &iflags);     // turn on DTR
    //ioctl(fd, TIOCMBIC, &iflags);    // turn off DTR

    if(tcgetattr(fd, &toptions) < 0)
    {
        perror(ARG_ERROR);
        return(-1);
    }

    //let you override switch below if needed
    speed_t baud = baudrate;
    switch(baud)
    {
        case 300    : baud = B300;   break;
        case 600    : baud = B600;   break;
        case 1200   : baud = B1200;  break;
        case 2400   : baud = B2400;  break;
        case 4800   : baud = B4800;  break;
        case 9600   : baud = B9600;  break;
        case 19200  : baud = B19200; break;
        case 38400  : baud = B38400; break;
        case 57600  : baud = B57600; break;
        case 115200 : baud = B115200; break;
    }

    //set baudrate speed
    cfsetispeed(&toptions, baud);
    cfsetospeed(&toptions, baud);

    // 8N1
    toptions.c_cflag &= ~PARENB;
    toptions.c_cflag &= ~CSTOPB;
    toptions.c_cflag &= ~CSIZE;
    toptions.c_cflag |= CS8;

    // no flow control
    toptions.c_cflag &= ~CRTSCTS;

    //toptions.c_cflag &= ~HUPCL; // disable hang-up-on-close to avoid reset
    toptions.c_cflag |= CREAD | CLOCAL;  // turn on READ & ignore ctrl lines
    toptions.c_iflag &= ~(IXON | IXOFF | IXANY); // turn off s/w flow ctrl
    toptions.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG); // make raw
    toptions.c_oflag &= ~OPOST; // make raw

    // see: http://unixwiz.net/techtips/termios-vmin-vtime.html
    toptions.c_cc[VMIN]  = 0;
    toptions.c_cc[VTIME] = 0;

    //toptions.c_cc[VTIME] = 20;
    tcsetattr(fd, TCSANOW, &toptions);
    if(tcsetattr(fd, TCSAFLUSH, &toptions) < 0)
    {
         perror(ARG_ERROR);
         return -1;
    }

    return fd;
}

int serial_port_close(int fd)
{
    return(close(fd));
}

//
int serial_port_writebyte( int fd, uint8_t byte)
{
    int n = write(fd,&byte,1);
    if( n!=1)
        return -1;
    return 0;
}

int serial_port_write(int fd, const char* str)
{
    int len = strlen(str);
    int n = write(fd, str, len);
    if(n != len)
    {
        perror(SERIAL_PORT_WRITE_ERROR);
        return -1;
    }
    return 0;
}

int serial_port_read_until(int fd, char* buf, char until, int buf_max, int timeout)
{
    char b[1];  // read expects an array, so we give it a 1-byte array
    int i=0;
    do
    {
        int n = read(fd, b, 1);  // read a char at a time
        if( n == -1 ) return -1;    // couldn't read
        if( n == 0 )
        {
            usleep( 1 * 1000 );  // wait 1 msec try again
            timeout--;
            continue;
        }
    #ifdef SERIALPORTDEBUG
            printf("serialport_read_until: i=%d, n=%d b='%c'\n",i,n,b[0]); // debug
    #endif
        buf[i] = b[0];
        i++;
    } while( b[0] != until && i < buf_max && timeout > 0 );

    buf[i] = 0;  // null terminate the string
    return 0;
}

int serial_port_flush(int fd)
{
    sleep(2); //required to make flush work, for some reason
    return tcflush(fd, TCIOFLUSH);
}
