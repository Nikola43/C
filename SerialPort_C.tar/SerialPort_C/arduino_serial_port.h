
#ifndef __ARDUINO_SERIAL_PORT_H__
#define __ARDUINO_SERIAL_PORT_H__

//Define msg
#define NO_NAME                      "serial_port_open: Serial port is not specified"
#define NO_BAUD                      "serial_port_open: Baudrate is not specified"
#define NO_ARG                       "serial_port_open: No data argument specified"
#define TOO_ARGC                     "serial_port_open: Too many arguments"
#define SERIAL_PORT_OPEN_OK          "serial_port_open: Open serial port successful"
#define SERIAL_PORT_OPEN_ERROR       "serial_port_open: Unable to open serial port"
#define CLOSE_SERIAL_OK              "serial_port_open: Close serial port sucessful"
#define CLOSE_SERIAL_PORT_ERROR      "serial_port_open: Unable to close serial port"
#define ARG_ERROR                    "serial_port_open: Couldn't get term attributes"
#define SEND_DATA_OK                 "serial_port_write: Sending data to serial port successfully completed"
#define SERIAL_PORT_WRITE_BYTE_OK    "serial_port_write_byte: Sending byte to serial port successfully completed"
#define SERIAL_PORT_WRITE_BYTE_ERROR "serial_port_write_byte: Sending byte to serial port error"
#define SERIAL_PORT_WRITE_OK         "serial_port_write: Sending data to serial port successfully completed"
#define SERIAL_PORT_WRITE_ERROR      "serial_port_write: Sending data to serial port error"

#include <stdint.h>   // Standard types

int serial_port_open(const char *serial_port_name, int baudrate);
int serial_port_close(int fd);
int serial_port_writebyte( int fd, uint8_t byte);
int serial_port_write(int fd, const char* str);
int serial_port_read_until(int fd, char* buf, char until, int buf_max,int timeout);
int serial_port_flush(int fd);

#endif


